=============================================
RocketTheme template patch for MageBridge
=============================================

Please visit our website www.yireo.com for installation instructions.

-> just add the directories and files from rt_template to your own RocketTheme template. No files need to be overwritten. Only directories will be merged.

-> To avoid loading css files from other webshops goto Extensions >> Template Manager -> open rt_mercado_j15 -> advanced -> set ECWID styling to NO.