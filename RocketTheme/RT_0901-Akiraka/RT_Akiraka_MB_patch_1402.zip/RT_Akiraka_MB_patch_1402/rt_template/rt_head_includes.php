<?php

// This information has been pulled out of index.php to make the template more readible.
//
// This data goes between the <head></head> tags of the template

?>

<link rel="shortcut icon" href="<?php echo $this->baseurl; ?>/images/favicon.ico" />
<link href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/css/template.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/css/typography.css" rel="stylesheet" type="text/css" />
<?php
/*
 * Yireo modifications for MageBridge
 */
if(class_exists('MageBridgeTemplateHelper')) {
    $mb = new MageBridgeTemplateHelper();

    if($mb->isLoaded()) {
        $this->addStylesheet($this->baseurl."/templates/".$this->template."/css/magebridge-styles.css");
        // the following is optional for the MageBridge homepage together with JM Product list module 
        if($mb->isHomePage()) { $this->addStylesheet($this->baseurl."/templates/".$this->template."/css/magebridge-frontpage.css");}
    	if (rok_isIe()) { 
    		$this->addStylesheet($this->baseurl."/templates/".$this->template."/css/magebridge-styles-ie.css");
		}
    }
}
/*
 * End Yireo modifications
 */
?>


<link href="<?php echo $this->baseurl ?>/templates/system/css/system.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $this->baseurl ?>/templates/system/css/general.css" rel="stylesheet" type="text/css" />
<?php if($mtype=="moomenu" or $mtype=="suckerfish") :?>
<link href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/css/rokmoomenu.css" rel="stylesheet" type="text/css" />
<?php endif; ?>
<style type="text/css">
	div.wrapper { <?php echo $template_width; ?>padding:0;}
	#leftcol { width:<?php echo $leftcolumn_width; ?>px;padding:0;}
	#rightcol { width:<?php echo $rightcolumn_width; ?>px;padding:0;}
	#inset-block-left { width:<?php echo $leftinset_width; ?>px;padding:0;}
	#inset-block-right { width:<?php echo $rightinset_width; ?>px;padding:0;}
	#maincontent-block { margin-right:<?php echo $rightinset_width; ?>px;margin-left:<?php echo $leftinset_width; ?>px;padding:0;}
	<?php if($fixed_header == "true") : ?>
	#header-main { position: fixed;top: 0;width: 100%;z-index: 10000;}
	<?php endif; ?>
	<?php if($fixed_footer == "true") : ?>
	#footer { position: fixed;bottom: 0;width: 100%;}
	<?php endif; ?>
	#header-main, #searchmod .inputbox {background-color: <?php echo $this->params->get( 'header_color' ); ?>;}
	#section1 {background: <?php echo $this->params->get( 'showcase_color' ); ?>;}
	#section2 {background: <?php echo $this->params->get( 'body_color' ); ?>;}
	#bottom-bar {background: <?php echo $this->params->get( 'botbar_color' ); ?>;}
	#bottom-section {background: <?php echo $this->params->get( 'botsection_color' ); ?>;}
	body, #footer {background: <?php echo $this->params->get( 'footer_color' ); ?>;}
	.line1, .logo-desc, #roksearch_results a {color: <?php echo $this->params->get( 'logo_text' ); ?>;}
	.featured-image {background: <?php echo $this->params->get( 'logo_text' ); ?>;}
	.article-image {background: <?php echo $this->params->get( 'body_text' ); ?>;}
	.article-image .line1 {color: <?php echo $this->params->get( 'body_text' ); ?>;}
	.rokbox-images img {border: 3px solid <?php echo $this->params->get( 'body_text' ); ?>;}
	body, #horiz-menu a, #horiz-menu .separator, .logo-module, #top-bar {color: <?php echo $this->params->get( 'header_text' ); ?>;}
	#top-bar a, .logo-module a {color: <?php echo $this->params->get( 'header_link' ); ?>;}
	#section1 {color: <?php echo $this->params->get( 'showcase_text' ); ?>;}
	#section1 a, #section1 h3, #section1 ul.menu li a, #section1 ul.menu li .separator, #section1 ul.menu li.active li a, #section1 ul.menu li.active li .separator, #section1 ul.menu li.active li.active li a, #section1 ul.menu li.active li.active li .separator span {color: <?php echo $this->params->get( 'showcase_link' ); ?>;}
	.front-showcase-desc em {background: <?php echo $this->params->get( 'showcase_highlight' ); ?>;color: <?php echo $this->params->get( 'showcase_highlight_text' ); ?>;}
	#section2 h3 span, .contentheading,h4 {color: <?php echo $this->params->get( 'body_highlight' ); ?>;}
	#section2, .roktabs-wrapper .dark .roktabs-links ul li, #section2 ul.menu li a, #section2 ul.menu li .separator, #section2 ul.menu li.active li a, #section2 ul.menu li.active li .separator, #section2 ul.menu li.active li.active li a, #section2 ul.menu li.active li.active li .separator {color: <?php echo $this->params->get( 'body_text' ); ?>;}
	h4 {border-bottom: 1px solid <?php echo $this->params->get( 'body_text' ); ?>;}
	#section2 a, #section2 legend, form.form-login .inputbox, #section2 h3, #main-body ul.menu li.active a, #main-body ul.menu li.active a:hover, #main-body ul.menu li.active .separator, #main-body ul.menu li.active .separator:hover, #main-body ul.menu li.active li.active a, #main-body ul.menu li.active li.active .separator, #main-body ul.menu li.active li.active li.active a, #main-body ul.menu li.active li.active li.active .separator, #main-body ul.menu li a:hover, #main-body ul.menu li .separator:hover, .roktabs-wrapper .dark .roktabs-links ul li.hover, .roktabs-wrapper .dark .roktabs-links ul.roktabs-top li.active, .roktabs-wrapper .dark .roktabs-links ul.roktabs-bottom li.active, span.number, span.inset-left, span.inset-right, span.dropcap, span.important-title, span.important-title-blue, span.important-title-red, span.important-title-green, span.important-title-purple, span.important-title-orange, span.important-title-brown, span.important-title-grey {color: <?php echo $this->params->get( 'body_link' ); ?>;}
	#bottom-bar {color: <?php echo $this->params->get( 'botbar_text' ); ?>;}
	#bottom-bar a {color: <?php echo $this->params->get( 'botbar_link' ); ?>;}
	#bottom-section, #copyright, #bottom-section h3 span {color: <?php echo $this->params->get( 'botsection_text' ); ?>;}
	#bottom-section a, #bottom-section h3 {color: <?php echo $this->params->get( 'botsection_link' ); ?>;}
	#footer, #footer a#clear-cookies {color: <?php echo $this->params->get( 'footer_text' ); ?>;}
	#footer a {color: <?php echo $this->params->get( 'footer_link' ); ?>;}
	<?php if (rok_isIe(6)) :?>
	#horiz-menu.suckerfish li:hover, #horiz-menu.suckerfish li.sfHover, #horiz-menu.splitmenu li:hover, #horiz-menu.splitmenu li.sfHover, .h-light #horiz-menu.suckerfish li:hover, .h-light #horiz-menu.suckerfish li.sfHover, .h-light #horiz-menu.splitmenu li:hover, .h-light #horiz-menu.splitmenu li.sfHover, #horiz-menu.suckerfish li li:hover, #horiz-menu.suckerfish li li.sfHover, #horiz-menu.splitmenu li li:hover, #horiz-menu.splitmenu li li.sfHover, .h-light #horiz-menu.suckerfish li li:hover, .h-light #horiz-menu.suckerfish li li.sfHover, .h-light #horiz-menu.splitmenu li li:hover, .h-light #horiz-menu.splitmenu li li.sfHover {background: <?php echo $this->params->get( 'header_color' ); ?>;}
	<?php endif; ?>
</style>	
<?php if (rok_isIe()) :?>
<!--[if IE 7]>
<link href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/css/template_ie7.css" rel="stylesheet" type="text/css" />	
<![endif]-->	
<?php endif; ?>
<?php if (rok_isIe(6)) :?>
<!--[if lte IE 6]>
<link href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/css/template_ie6.css" rel="stylesheet" type="text/css" />
<script src="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/js/DD_belatedPNG.js"></script>
<script type="text/javascript">
	window.addEvent('load', function() { DD_belatedPNG.fix('.png'); });
	window.addEvent('domready', function() {
		var lockButton = $('lock-button');
		if (lockButton) {
			lockButton.addEvent('click', function() {
				(function() {
					var pngs = $$('#rokbox-container #login-module')[0].getElements('.png');
					pngs.each(function(png) {
						DD_belatedPNG.fixPng(png);
					});
				}).delay(1000)
			});
		}
	});
</script>
<![endif]-->
<?php endif; ?>
<?php if(rok_isIe(6) and $enable_ie6warn=="true" and $js_compatibility=="false") : ?> 
<script type="text/javascript" src="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/js/rokie6warn.js"></script> 
<?php endif; ?>
<script type="text/javascript">
	window.fixedHeader = <?php echo $fixed_header; ?>;
	window.fixedFooter = <?php echo $fixed_footer; ?>;
</script>
<script type="text/javascript" src="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/js/rokutils.js"></script>
<?php if($enable_fontspans=="true") :?>
<script type="text/javascript" src="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/js/rokfonts.js"></script>
<script type="text/javascript">
	window.addEvent('domready', function() {
		var modules = ['side-mod-surround','module','moduletable'];
		var header = "h3";
		RokBuildSpans(modules, header);
	});
</script>
<?php endif; ?>
<?php if($mtype=="moomenu" and $js_compatibility=="false") :?>
<script type="text/javascript" src="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/js/rokmoomenu.js"></script>
<script type="text/javascript" src="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/js/mootools.bgiframe.js"></script>
<script type="text/javascript">
window.addEvent((window.webkit) ? 'load' : 'domready', function() {
	new Rokmoomenu($E('ul.menutop '), {
		bgiframe: <?php echo $moo_bgiframe; ?>,
		delay: <?php echo $moo_delay; ?>,
		verhor: true,
		animate: {
			props: ['height'],
			opts: {
				duration: <?php echo $moo_duration; ?>,
				fps: <?php echo $moo_fps; ?>,
				transition: Fx.Transitions.<?php echo $moo_transition; ?>
			}
		},
		bg: {
			enabled: <?php echo $moo_bg_enabled; ?>,
			overEffect: {
				duration: <?php echo $moo_bg_over_duration; ?>,
				transition: Fx.Transitions.<?php echo $moo_bg_over_transition; ?>
			},
			outEffect: {
				duration: <?php echo $moo_bg_out_duration; ?>,
				transition: Fx.Transitions.<?php echo $moo_bg_out_transition; ?>
			}
		},
		submenus: {
			enabled: <?php echo $moo_sub_enabled; ?>,
			overEffect: {
				duration: <?php echo $moo_sub_over_duration; ?>,
				transition: Fx.Transitions.<?php echo $moo_sub_over_transition; ?>
			},
			outEffect: {
				duration: <?php echo $moo_sub_out_duration; ?>,
				transition: Fx.Transitions.<?php echo $moo_sub_out_transition; ?>
			},
			offsets: {
				top: <?php echo $moo_sub_offsets_top; ?>,
				right: <?php echo $moo_sub_offsets_right; ?>,
				bottom: <?php echo $moo_sub_offsets_bottom; ?>,
				left: <?php echo $moo_sub_offsets_left; ?>
			}
		}
	});
});
</script>
<?php endif; ?>
<?php if((rok_isIe(6) or rok_isIe(7)) and ($mtype=="suckerfish" or $mtype=="splitmenu")) :
  echo "<script type=\"text/javascript\" src=\"" . $this->baseurl . "/templates/" . $this->template . "/js/ie_suckerfish.js\"></script>\n";
endif; ?>