<?php
/**
 * @package   MageBridge Template patch - Yireo
 * @version   1.5.0 July 8, 2010
 * @author    Yireo http://www.yireo.com
 * @copyright Copyright (C) 2009 - 2010 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 *
 * MageBridge Template patch uses the Joomla Framework (http://www.joomla.org), a GNU/GPLv2 content management system
 *
 */
defined('JPATH_BASE') or die();

gantry_import('core.gantryfeature');

class GantryFeatureMageBridge extends GantryFeature {
    var $_feature_name = 'magebridge';

    function isEnabled() {
		if(class_exists('MageBridgeTemplateHelper')) {
            return true;
        }
        return true;
    }

    function isInPosition($position) {
        return false;
    }

	function init() {
        global $gantry;

		if(!class_exists('MageBridgeTemplateHelper')) {
            return;
        }
		
		$mb = new MageBridgeTemplateHelper();
		if($mb->isLoaded()) {
			$gantry->addStyle('magebridge.css');
			
	        //inline css for dynamic stuff
			$path = $gantry->templateUrl.'/images';
			$css = '
				button.button {background:url('.$path.'/body/'.$gantry->get('body-overlay').'/readon-r.png) repeat scroll 100% 0 transparent;height:36px;margin:0 0 0 26px;padding:0;}
				button.button span {background:url('.$path.'/body/'.$gantry->get('body-overlay').'/readon-l.png) no-repeat scroll 0 0 transparent;color:'.$gantry->get('module1-link').';font:12px/36px Verdana,Arial,Helvetica,sans-serif;height:36px;margin:0 0 0 -26px;padding:0 18px 0 32px;}
				button.button:hover {background-position:100% -43px !important;}
				button.button:hover span {background-position:0 -43px !important;color:'.$gantry->get('module1-text').';}
				.opc .active .step-title h2 {color:'.$gantry->get('header-link').';}
				.opc .active .step-title .number {background:'.$gantry->get('header-link').';border-color:'.$gantry->get('header-link').';}
				.opc .step {background:'.$gantry->get('module1-background').';color:'.$gantry->get('module1-text').';}
				#magebridge-content .cart {color:'.$gantry->get('body-text').';}
				'."\n";
				
	        $gantry->addInlineStyle($css);
	
	        //style stuff
	        //$gantry->addStyle($gantry->get('cssstyle').".css");
		}
	}
} 