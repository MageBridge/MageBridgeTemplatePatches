<?php

// This information has been pulled out of index.php to make the template more readible.
//
// This data goes between the <head></head> tags of the template
// 
// 

$this->addStylesheet($this->baseurl."/templates/".$this->template."/css/template.css");
$this->addStylesheet($this->baseurl."/templates/".$this->template."/css/styles.css");
$this->addStylesheet($this->baseurl."/templates/".$this->template."/css/typography.css");
$this->addStylesheet($this->baseurl."/templates/system/css/system.css");
$this->addStylesheet($this->baseurl."/templates/system/css/general.css");
if($mtype=="moomenu" or $mtype=="suckerfish") :
    $this->addStylesheet($this->baseurl."/templates/".$this->template."/css/rokmoomenu.css");
endif;
/*
 * Yireo modifications for MageBridge
 */
if(class_exists('MageBridgeTemplateHelper')) {
    $mb = new MageBridgeTemplateHelper();

    if($mb->isLoaded()) {
        $this->addStylesheet($this->baseurl."/templates/".$this->template."/css/magebridge-styles.css");
        // the following is optional for the MageBridge homepage together with JM Product list module 
        if($mb->isHomePage()) { $this->addStylesheet($this->baseurl."/templates/".$this->template."/css/magebridge-frontpage.css");}
    }

    if (rok_isIe()) { ?>
        <!--[if gte IE 7]>
        <style type="text/css">
            .form-button span, .form-button-alt span {margin-top:-1px;}
        </style>
        <![endif]-->
    <?php }
}
/*
 * End Yireo modifications
 */
$inlinestyle = "
    body.iehandle #main-background {background-attachment:".$bg_fixed.";}
	div.wrapper { ".$template_width."padding:0;}
	#inset-block-left { width:".$leftinset_width."px;padding:0;}
	#inset-block-right { width:".$rightinset_width."px;padding:0;}
	#maincontent-block { margin-right:".$rightinset_width."px;margin-left:".$leftinset_width."px;}
	#main-body ul.menu li a:hover, ul.roknewspager-numbers li.active, .feature-block .feature-desc, #horiz-menu li.active .link span, #horiz-menu li:hover .link span, #horiz-menu li.sfHover .link span, #horiz-menu li:hover li:hover .link span, #horiz-menu li:hover li:hover li:hover .link span, #horiz-menu li.sfHover li.sfHover .link span, #horiz-menu li.sfHover li.sfHover li.sfHover .link span, #showcase-section, .side-mod h3, #searchmod-surround h3, #main-body ul.menu li a:hover, ul.roknewspager-numbers li.active, a:hover, #featuremodules {color: ".$showcase_text.";}
	#showcase-section .feature-block .feature-title {color:".$showcase_title.";}
	#showcase-section a {color: ".$showcase_link.";}
	.variation-chooser input, #mainbody-overlay, #searchmod-surround .inputbox, form.search_result input.button, form.poll input.button, form.form-login .inputbox, form.form-login input.button, form.log input.button, #bottom, form#emailForm input.button, #copyright, #top-button a, input#search_searchword.inputbox, form.search_result legend, .contact_email .inputbox, .readon-wrap1 input.button, input#email.required, .logo-module, .footer-mod {color: ".$body_text.";}
	#roktwittie .status .header .nick, .search-results-full span.highlight, #main-background div.articleListingImage img, #main-background div.sbArticleImage img  {background:".$body_link.";}
	a, .contentheading, #horiz-menu li:hover li .link span, #horiz-menu li:hover li:hover li .link span, #horiz-menu li.sfHover li .link span, #horiz-menu li.sfHover li.sfHover li .link span, .componentheading span, .roktabs-links li.active, .side-mod h3 span, .showcase-panel h3 span, #featuremodules h3 {color: ".$body_link.";}";
$this->addStyleDeclaration($inlinestyle);
?>
<?php if (rok_isIe()) :?>
<!--[if IE 7]>
<link href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/css/template_ie7.css" rel="stylesheet" type="text/css" />	
<![endif]-->	
<?php endif; ?>
<?php if (rok_isIe(6)) :?>
<!--[if lte IE 6]>
<link href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/css/template_ie6.css" rel="stylesheet" type="text/css" />
<script src="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/js/DD_belatedPNG.js"></script>
<script type="text/javascript">
	var pngClasses = ['.png', '.menutop li.active a', '.readon1-l', '.readon1-m', '.readon1-r', '#roktwittie .status .header', '.blog .roknewspager-div', '.control-prev', '.control-next', '.control-prev-hover', '#main-body ul.menu li', '.roknewspager-div', '#main-body ul.menu li a', '.roknewspager-pages', '.roknewspager-prev-disabled', '.roknewspager-prev', '.roknewspager-next-disabled', '.roknewspager-numbers', '.roknewspager-next', '#roktwittie .roktwittie-surround', 'a.sbDisqusCounter', 'div.superBloggerTop', 'div.sbRating', 'div.sbAuthorBlock', '#disqus_thread', 'div.superBloggerTop a', 'div.superBloggerTop img', '.sbAuthorLatestTweets ul li', '.sbAuthorLatest ul li', 'span.ob_commentOut', '#roksearch_results .roksearch_row_btm', '#roksearch_results .roksearch_header', '#roksearch_results', '#roksearch_results .roksearch_odd', '#roksearch_results .roksearch_even', '#roksearch_results .roksearch_even-hover', '#roksearch_results .roksearch_odd-hover', 'pre', 'blockquote', 'th.sectiontableheader', '.roktabs-links ul li span', '.roktabs-links ul li.active', '.roktabs-wrapper .arrow-next', '.roktabs-wrapper .arrow-prev', '.active-arrows'];
	
	pngClasses.each(function(fixMePlease) {
		DD_belatedPNG.fix(fixMePlease);
	});
	
</script>
<![endif]-->
<?php endif; ?>
<?php
/* Javascript Hooks for base uri */
	$tmpl_folder = "
		window.templatePath = '$template_path';
		window.uri = '{$this->baseurl}';
		window.currentStyle = '$tstyle';
	";
	$this->addScriptDeclaration($tmpl_folder);
?>
<?php 
if($enable_fontspans=="true") :
    $this->addScript($this->baseurl."/templates/".$this->template."/js/rokfonts.js");
    $rokfonts = 
    "window.addEvent('domready', function() {
		var modules = ['side-mod', 'showcase-panel'];
		var header = ['h3','h1'];
		RokBuildSpans(modules, header);
	});";
    $this->addScriptDeclaration($rokfonts);
endif;
if(rok_isIe(6) and $enable_ie6warn=="true" and $js_compatibility=="false") : 
    $this->addScript($this->baseurl."/templates/".$this->template."/js/rokie6warn.js");
endif;
$this->addScript($this->baseurl."/templates/".$this->template."/js/rokutils.js");
if($enable_inputstyle == "true" and $js_compatibility=="false" and !rok_isIe(6)) :
    $this->addScript($this->baseurl."/templates/".$this->template."/js/rokutils.inputs.js");
	$exclusionList = "InputsExclusion.push($inputs_exclusion)";
	$this->addScriptDeclaration($exclusionList);
endif;
if($enable_featured_effects=="true" and $js_compatibility=="false" and !rok_isIe()) :
	$featfx = 
	"window.addEvent('domready', function() {
		var featured = $('featuremodules'), featOpacity = 0.7;
		if (featured) {
			var featChildren = featured.getChildren();
			if (featChildren.length > 1) {
				featChildren.each(function(feat, i) {
					var color = feat.getStyle('color');
					var lnks = feat.getElements('a');
					var h3s = feat.getElements('h3');
					
					var fxColors = [];
					if (lnks.length > 0) {
						var lnkColor = feat.getElement('a').getStyle('color');
						lnks.each(function(lnk, i) { fxColors.push(new Fx.Style(lnk, 'color', {wait: false}).set(color)); });
					}
					
					var fxH3s = [];
					if (h3s.length > 0) {
						var h3Color = feat.getElement('h3').getStyle('color');
						h3s.each(function(h3, i) { fxH3s.push(new Fx.Style(h3, 'color', {wait: false}).set(color));	});
					}
					
					var fx = new Fx.Style(feat, 'opacity', {duration: 300, wait: false}).set(featOpacity);
					
					feat.addEvents({
						'mouseenter': function() {
							fx.start(1);
							if (fxColors.length) { fxColors.each(function(fxC) { fxC.start(lnkColor); }); }
							if (fxH3s.length) { fxH3s.each(function(fxH) { fxH.start(h3Color); }); }
						},
						'mouseleave': function() {
							fx.start(featOpacity);
							if (fxColors.length) { fxColors.each(function(fxC) { fxC.start(color); }); }
							if (fxH3s.length) {	fxH3s.each(function(fxH) { fxH.start(color); }); }
						}
					})
				});
			}
		}	
	});";
	$this->addScriptDeclaration($featfx);
endif;
if($this->countModules('showcase-panel')):
	$showcasepanel = "
		window.showcasePanelOptions = {
			'hooks': '$panel_hooks',
			'fixedHeight': $panel_fixheight,
			'height': $panel_height,
			'opacity': $panel_opacity,
			'scrollToTop': $panel_totop,
			'closeByClick': $panel_clickclose,
			'showCloseButton': $panel_closebutton
		};";
	$this->addScriptDeclaration($showcasepanel);
endif;
if($mtype=="moomenu" and $js_compatibility=="false") :
    $this->addScript($this->baseurl."/templates/".$this->template."/js/rokmoomenu.js");
    $this->addScript($this->baseurl."/templates/".$this->template."/js/mootools.bgiframe.js");
    $mooinit =
    "window.addEvent('domready', function() {
    	new Rokmoomenu(".'$E'."('ul.menutop '), {
    		bgiframe: ".$moo_bgiframe.",
    		delay: ".$moo_delay.",
    		verhor: true,
    		animate: {
    			props: ['height'],
    			opts: {
    				duration: ".$moo_duration.",
    				fps: ".$moo_fps.",
    				transition: Fx.Transitions.".$moo_transition."
    			}
    		},
    		bg: {
    			enabled: ".$moo_bg_enabled.",
    			overEffect: {
    				duration: ".$moo_bg_over_duration.",
    				transition: Fx.Transitions.".$moo_bg_over_transition."
    			},
    			outEffect: {
    				duration: ".$moo_bg_out_duration.",
    				transition: Fx.Transitions.".$moo_bg_out_transition."
    			}
    		},
    		submenus: {
    			enabled: ".$moo_sub_enabled.",
    			opacity: ".$moo_sub_opacity.",
    			overEffect: {
    				duration: ".$moo_sub_over_duration.",
    				transition: Fx.Transitions.".$moo_sub_over_transition."
    			},
    			outEffect: {
    				duration: ".$moo_sub_out_duration.",
    				transition: Fx.Transitions.".$moo_sub_out_transition."
    			},
    			offsets: {
    				top: ".$moo_sub_offsets_top.",
    				right: ".$moo_sub_offsets_right.",
    				bottom: ".$moo_sub_offsets_bottom.",
    				left: ".$moo_sub_offsets_left."
    			}
    		}
    	});
    });";
    $this->addScriptDeclaration($mooinit);
endif;
if((rok_isIe(6) or rok_isIe(7)) and ($mtype=="suckerfish" or $mtype=="splitmenu")) :
    $this->addScript($this->baseurl."/templates/".$this->template."/js/ie_suckerfish.js");

endif; ?>