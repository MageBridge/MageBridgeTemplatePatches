=============================================
YOOtheme template patch for MageBridge
=============================================

Please visit our website www.yireo.com for installation instructions.
