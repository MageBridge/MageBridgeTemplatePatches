=============================================
YOOtheme template patch for MageBridge
=============================================

Please visit our website www.yireo.com for installation instructions.

-> just add the directories and files from yoo_template to your own YOOtheme template. No files need to be overwritten. Only directories will ben merged.
